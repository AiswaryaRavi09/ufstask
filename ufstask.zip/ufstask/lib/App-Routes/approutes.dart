class AppRoute {
  static String riskassessment = "/riskassessment";

}