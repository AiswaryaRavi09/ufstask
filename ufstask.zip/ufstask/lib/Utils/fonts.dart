
import 'dart:ui';

import 'package:google_fonts/google_fonts.dart';

import 'Colors.dart';

final risktext=GoogleFonts.dmSans(
  fontWeight: FontWeight.w700,
  fontSize:18,
  color:firstScreen1,
);
final hazarttext=GoogleFonts.roboto(
  fontWeight: FontWeight.w500,
  fontSize:16,
  color:firstScreen1,
);