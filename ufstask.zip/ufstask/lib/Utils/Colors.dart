import 'dart:ui';

Color firstScreen = const Color(0xffE5F1FF);
Color firstScreen1 = const Color(0xff294C73);
Color firstScreenskip = const Color(0xffFFF1CD);
Color firstScreennext = const Color(0xffE5AA17);
Color firstScreencontainer = const Color(0xffF9F9F9);
Color firstScreenappbar = const Color(0xffF7F7F9);
