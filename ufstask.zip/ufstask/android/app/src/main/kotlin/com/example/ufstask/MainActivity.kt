package com.example.ufstask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
